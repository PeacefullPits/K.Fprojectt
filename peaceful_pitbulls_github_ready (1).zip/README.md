# Peaceful Pitbulls

This is a community project created by K.F to raise awareness and change the perception of pitbulls. It shows that pitbulls can be loving, kind, and heroic pets when raised in a good environment.

## Live Site

Once deployed via GitHub Pages, it will be viewable at:
```
https://<your-username>.github.io/peaceful-pitbulls/
```

## How to Use

1. Upload this project to a GitHub repository.
2. Go to the repository's Settings > Pages.
3. Set the source to `main` branch and `/ (root)` folder.
4. Save and get the public URL.
